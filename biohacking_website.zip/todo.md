# Biohacking Website Improvement Todo List

## Website Requirements Analysis
- [x] Review current website structure and content
- [x] Review assignment requirements
- [x] Identify HTML and CSS errors
- [x] Check for missing assignment requirements

## Assignment Requirements Checklist
- [x] Create three pages (currently only has index page)
- [x] Add "Skip to Main Content" link (visible only on focus)
- [x] Ensure accessible, attractively styled navigation
- [x] Implement grid property on at least one parent element
- [x] Implement flex property on at least one parent element
- [x] Style all images using box model (border, padding, border-radius)
- [x] Update at least one element using hover pseudo-class
- [x] Implement nth-child selector
- [x] Ensure at least one page has 5+ images
- [x] Replace placeholder images with appropriate diverse images
- [ ] Validate HTML using W3 validator
- [ ] Validate accessibility using WAVE tool

## Implementation Tasks
- [x] Create HTML structure for all three pages
- [x] Implement proper CSS styling according to requirements
- [x] Create/optimize all necessary graphics
- [x] Ensure responsive design for mobile and desktop
- [x] Test all links and navigation
- [ ] Fix any validation errors

## Final Delivery
- [x] Package all files for GitHub upload
- [ ] Provide clear documentation on file structure
- [ ] Create final report on improvements made
